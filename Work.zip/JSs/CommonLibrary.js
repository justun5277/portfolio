function getStyle(element, name){
    var res;
    if(window.getComputedStyle){
        res = getComputedStyle(element,null)[name];
    }else{
        res = element.currentStyle[name];
    }
    
    return res;
}

function move(obj, attr, tar, offset, endAction){

    clearInterval(obj.timer);

    var nowVal = parseInt(getStyle(obj,attr));

    if(nowVal > tar) offset = -offset;

    obj.timer = setInterval(function (){
        
        var nowVal = parseInt(getStyle(obj,attr));

        newVal = nowVal + offset;

        if((offset > 0 && newVal > tar) || (offset < 0 && newVal < tar)){
            newVal = tar;         
        }

        obj.style[attr] = newVal + "px";

        if(newVal === tar){
            clearInterval(obj.timer);
            endAction && endAction();
        }      
    }, 30);
}

function getContentFun(n){

    return function(){
        let xhr = new XMLHttpRequest();

        xhr.open('GET', `http://127.0.0.1:8000/getPage?x=${n}`);

        xhr.send();

        xhr.onreadystatechange = function(){
            if(xhr.readyState === 4){
                if(xhr.status === 200){
                    document.getElementById('mainContent').innerHTML = xhr.responseText;
                }
            }
        }    
    }
}